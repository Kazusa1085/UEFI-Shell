/** @file
  This is an empty C source file used in VS20xx HOST_APPLICATION
  builds.

  Copyright (c) 2024, Intel Corporation. All rights reserved.<BR>
  SPDX-License-Identifier: BSD-2-Clause-Patent
**/
